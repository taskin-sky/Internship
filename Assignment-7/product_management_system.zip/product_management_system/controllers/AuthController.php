<?php
session_start();
include_once '../config/Database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['action'] == 'register') {
    // Sanitize input
    $username = htmlspecialchars(strip_tags($_POST['username']));
    $email = htmlspecialchars(strip_tags($_POST['email']));
    $password = htmlspecialchars(strip_tags($_POST['password']));

    // Validate input
    $errors = [];
    if (empty($username)) {
        $errors[] = 'Username is required';
    }
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'A valid email is required';
    }
    if (empty($password)) {
        $errors[] = 'Password is required';
    }

    // If no errors, proceed with registration
    if (empty($errors)) {
        // Get database connection
        $database = new Database();
        $db = $database->getConnection();

        // Check if the email already exists
        $query = "SELECT id FROM users WHERE email = :email LIMIT 1";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            // Email already exists
            $errors[] = 'This email is already registered. Please use a different email or log in.';
            $_SESSION['errors'] = $errors;
            header("Location: ../views/auth/register.php");
            exit();
        }

        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert user into database
        $query = "INSERT INTO users (username, email, password) VALUES (:username, :email, :password)";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $hashed_password);

        if ($stmt->execute()) {
            // Registration successful
            $_SESSION['message'] = 'Registration successful. <br>You can now log in.';
            header("Location: ../views/auth/login.php");
            exit();
        } else {
            // Registration failed
            $_SESSION['error'] = 'Registration failed. Please try again.';
            header("Location: ../views/auth/register.php");
            exit();
        }
    } else {
        // Validation errors
        $_SESSION['errors'] = $errors;
        header("Location: ../views/auth/register.php");
        exit();
    }
}
?>
