<?php
class Validation {
    public function sanitize($data) {
        return htmlspecialchars(strip_tags($data));
    }

    public function validateRegistration($username, $email, $password) {
        $errors = [];
        if (empty($username)) {
            $errors['username'] = 'Username is required';
        }
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Valid email is required';
        }
        if (empty($password)) {
            $errors['password'] = 'Password is required';
        }
        return $errors;
    }

    public function validateProduct($name, $price) {
        $errors = [];
        if (empty($name)) {
            $errors['name'] = 'Product name is required';
        }
        if (empty($price) || !is_numeric($price)) {
            $errors['price'] = 'Valid price is required';
        }
        return $errors;
    }
}
?>
