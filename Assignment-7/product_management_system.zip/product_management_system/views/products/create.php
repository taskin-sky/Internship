<?php $view = __FILE__; include('../layout.php'); ?>

<?php if (isset($_SESSION['errors'])): ?>
    <div class="errors">
        <ul>
            <?php foreach ($_SESSION['errors'] as $error): ?>
                <li><?php echo $error; ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php unset($_SESSION['errors']); endif; ?>

<?php if (isset($_SESSION['message'])): ?>
    <div class="success">
        <p><?php echo $_SESSION['message']; ?></p>
    </div>
<?php unset($_SESSION['message']); endif; ?>

<form action="../../controllers/ProductController.php" method="POST">
    <h2>Add New Product</h2>
    <input type="text" name="name" placeholder="Product Name" required>
    <input type="text" name="price" placeholder="Price" required>
    <textarea name="description" placeholder="Description"></textarea>
    <input type="hidden" name="action" value="create">
    <button type="submit">Add Product</button>
</form>
