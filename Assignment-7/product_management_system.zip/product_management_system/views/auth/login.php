<?php $view = __FILE__; include('../layout.php'); ?>

<?php if (isset($_SESSION['message'])): ?>
    <div class="success">
        <p><?php echo $_SESSION['message']; ?></p>
    </div>
<?php unset($_SESSION['message']); endif; ?>

<?php if (isset($_SESSION['error'])): ?>
    <div class="error" style="color: red;">
        <p><?php echo $_SESSION['error']; ?></p>
    </div>
<?php unset($_SESSION['error']); endif; ?>

<form action="../../controllers/AuthController.php" method="POST">
    <h2>Login</h2>
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="hidden" name="action" value="login">
    <button type="submit">Login</button>
</form>
