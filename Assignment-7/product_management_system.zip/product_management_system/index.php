<?php
header("Location: views/products/index.php");
exit;
?>
