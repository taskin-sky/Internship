<?php
header("Location: views/products/home.php");
exit;
?>
