<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    
</head>
<body>
    <header>
        <h1>Product Management System</h1>
        <nav>
            <ul>
                <li><a href="../products/home.php">Home</a></li>
                <li><a href="../auth/login.php">Login</a></li>
                <li><a href="../auth/register.php">Register</a></li>
                
            </ul>
        </nav>
    </header>
    <main class="container">
        <?php if (isset($_SESSION['errors'])): ?>
            <div class="errors">
                <ul>
                    <?php foreach ($_SESSION['errors'] as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php unset($_SESSION['errors']); endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="error">
                <p><?php echo $_SESSION['error']; ?></p>
            </div>
        <?php unset($_SESSION['error']); endif; ?>

    </main>

    <footer class="footer">
        <p>&copy; Product Management System [taskin]</p>
    </footer>

</body>
</html>
