<?php
$view = __FILE__; include('../layout.php');
include_once '../../config/Database.php';
include_once '../../models/Product.php';

$database = new Database();
$db = $database->getConnection();

$product = new Product($db);

$product->id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: missing ID.');
$product->readSingle();
?>



<?php if (isset($_SESSION['errors'])): ?>
    <div class="errors">
        <ul>
            <?php foreach ($_SESSION['errors'] as $error): ?>
                <li><?php echo $error; ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php unset($_SESSION['errors']); endif; ?>

<div class="form-container">
    
    <form action="../../controllers/ProductController.php" method="POST">
        <h2>Edit Product</h2>
        <input type="hidden" name="id" value="<?php echo $product->id; ?>">
        <input type="text" name="name" placeholder="Product Name" value="<?php echo $product->name; ?>" required>
        <input type="text" name="price" placeholder="Price" value="<?php echo $product->price; ?>" required>
        <textarea name="description" placeholder="Description"><?php echo $product->description; ?></textarea>
        <input type="hidden" name="action" value="update">
        <button type="submit">Update Product</button>
    </form>
</div>