<?php 
$view = __FILE__; include('../layout.php');
include_once '../../config/Database.php';
include_once '../../models/Product.php';

$database = new Database();
$db = $database->getConnection();

$product = new Product($db);
$stmt = $product->read();
?>

<div class="form-container" id="home-css">
    <h2>All Products</h2>
    <div container class="product-list">
        <?php while ($row = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
            <div class="product-item">
                <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                <p>Price: $<?php echo htmlspecialchars($row['price']); ?></p>
                <p><?php echo htmlspecialchars($row['description']); ?></p>
            </div>
        <?php endwhile; ?>
    </div>
</div>

