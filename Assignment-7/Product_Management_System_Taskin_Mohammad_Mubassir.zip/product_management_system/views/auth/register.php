<?php $view = __FILE__; include('../layout.php'); ?>

<?php if (isset($_SESSION['errors'])): ?>
    <div class="errors">
        <ul>
            <?php foreach ($_SESSION['errors'] as $error): ?>
                <li><?php echo $error; ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php unset($_SESSION['errors']); endif; ?>

<?php if (isset($_SESSION['message'])): ?>
    <div class="success">
        <p><?php echo $_SESSION['message']; ?></p>
    </div>
<?php unset($_SESSION['message']); endif; ?>

<div class="form-container">
    <form action="../../controllers/AuthController.php" method="POST">
        <h2>Register</h2>
        <input type="text" name="username" placeholder="Username" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="hidden" name="action" value="register">
        <button type="submit">Register</button>
    </form>
</div>