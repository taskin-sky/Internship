<?php
session_start();
include_once '../config/Database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($_POST['action'] == 'register') {
        // Handle Registration
        $username = htmlspecialchars(strip_tags($_POST['username']));
        $email = htmlspecialchars(strip_tags($_POST['email']));
        $password = htmlspecialchars(strip_tags($_POST['password']));

        $errors = [];
        if (empty($username)) {
            $errors[] = 'Username is required';
        }
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'A valid email is required';
        }
        if (empty($password)) {
            $errors[] = 'Password is required';
        }

        if (empty($errors)) {
            $database = new Database();
            $db = $database->getConnection();

            $query = "SELECT id FROM users WHERE email = :email LIMIT 1";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':email', $email);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                $errors[] = 'This email is already registered. Please use a different email or log in.';
                $_SESSION['errors'] = $errors;
                header("Location: ../views/auth/register.php");
                exit();
            }

            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $query = "INSERT INTO users (username, email, password) VALUES (:username, :email, :password)";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':password', $hashed_password);

            if ($stmt->execute()) {
                $_SESSION['message'] = 'Registration successful. <br>You can now log in.';
                header("Location: ../views/auth/login.php");
                exit();
            } else {
                $_SESSION['error'] = 'Registration failed. Please try again.';
                header("Location: ../views/auth/register.php");
                exit();
            }
        } else {
            $_SESSION['errors'] = $errors;
            header("Location: ../views/auth/register.php");
            exit();
        }
    } elseif ($_POST['action'] == 'login') {
        // Handle Login
        $email = htmlspecialchars(strip_tags($_POST['email']));
        $password = htmlspecialchars(strip_tags($_POST['password']));

        $errors = [];
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'A valid email is required';
        }
        if (empty($password)) {
            $errors[] = 'Password is required';
        }

        if (empty($errors)) {
            $database = new Database();
            $db = $database->getConnection();

            $query = "SELECT id, username, password FROM users WHERE email = :email LIMIT 1";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':email', $email);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                if (password_verify($password, $row['password'])) {
                    // Login successful
                    $_SESSION['user_id'] = $row['id'];
                    $_SESSION['username'] = $row['username'];
                    // $_SESSION['message'] = 'Login successful';
                    
                    
                    
                    header("Location: ../views/products/index.php");
                    exit();
                } else {
                    $errors[] = 'Incorrect password. Please try again.';
                }

            } else {
                $errors[] = 'No account found with that email.';
            }
            
            $_SESSION['error'] = implode('<br>', $errors);
            header("Location: ../views/auth/login.php");
            exit();
        } else {
            $_SESSION['error'] = implode('<br>', $errors);
            header("Location: ../views/auth/login.php");
            exit();
        }
    }
}
