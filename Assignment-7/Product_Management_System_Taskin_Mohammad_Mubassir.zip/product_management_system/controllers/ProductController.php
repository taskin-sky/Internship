<?php
session_start();
include_once '../config/Database.php';
include_once '../models/Product.php';

$database = new Database();
$db = $database->getConnection();
$product = new Product($db);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($_POST['action'] == 'create') {
        // Sanitize input
        $name = htmlspecialchars(strip_tags($_POST['name']));
        $price = htmlspecialchars(strip_tags($_POST['price']));
        $description = htmlspecialchars(strip_tags($_POST['description']));

        // Validate input
        $errors = [];
        if (empty($name)) {
            $errors[] = 'Product name is required';
        }
        if (empty($price) || !is_numeric($price)) {
            $errors[] = 'A valid price is required';
        }

        // If no errors, proceed with product creation
        if (empty($errors)) {
            $product->name = $name;
            $product->price = $price;
            $product->description = $description;

            if ($product->create()) {
                $_SESSION['message'] = 'Product added successfully!';
            } else {
                $_SESSION['error'] = 'Product creation failed. Please try again.';
            }
            header("Location: ../views/products/index.php");
            exit();
        } else {
            $_SESSION['errors'] = $errors;
            header("Location: ../views/products/create.php");
            exit();
        }
    } elseif ($_POST['action'] == 'update') {
        // Sanitize input
        $id = htmlspecialchars(strip_tags($_POST['id']));
        $name = htmlspecialchars(strip_tags($_POST['name']));
        $price = htmlspecialchars(strip_tags($_POST['price']));
        $description = htmlspecialchars(strip_tags($_POST['description']));

        // Validate input
        $errors = [];
        if (empty($name)) {
            $errors[] = 'Product name is required';
        }
        if (empty($price) || !is_numeric($price)) {
            $errors[] = 'A valid price is required';
        }

        // If no errors, proceed with product update
        if (empty($errors)) {
            $product->id = $id;
            $product->name = $name;
            $product->price = $price;
            $product->description = $description;

            if ($product->update()) {
                $_SESSION['message'] = 'Product updated successfully!';
            } else {
                $_SESSION['error'] = 'Product update failed. Please try again.';
            }
            header("Location: ../views/products/index.php");
            exit();
        } else {
            $_SESSION['errors'] = $errors;
            header("Location: ../views/products/edit.php?id=$id");
            exit();
        }
    }
} elseif ($_GET['action'] == 'delete') {
    // Delete product
    $product->id = $_GET['id'];
    if ($product->delete()) {
        $_SESSION['message'] = 'Product deleted successfully!';
    } else {
        $_SESSION['error'] = 'Product deletion failed. Please try again.';
    }
    header("Location: ../views/products/index.php");
    exit();
}
?>
