-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 04, 2024 at 01:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `product_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `description`, `created_at`) VALUES
(4, 'Xiaomi TV A2 55', 75000.00, 'Display Type: 4K UHD\r\nResolution: 3,840 x 2,160', '2024-09-01 22:09:00'),
(15, 'Intel 13th Gen Core i9 13900K Gaming Desktop PC', 374999.00, 'Intel 13th Gen Core i9 13900K Raptor Lake Processor\r\nGIGABYTE Z790 UD AX ATX Motherboard', '2024-09-02 22:52:40'),
(16, 'iPhone 16 Pro', 180000.00, 'Best camera: 48MP\r\nPowerful chipset: A18 Pro chip ', '2024-09-03 00:17:49'),
(25, 'Royal Enfield Classic 350', 350000.00, '6100 rpm\r\n4 Stroke, Air-Oil Cooled Engine, Spark Ignition, Single Cylinder', '2024-09-03 20:09:45'),
(26, 'Samsung Galaxy S24 Ultra', 130000.00, 'OS	: Android 14, up to 7 major Android upgrades, One UI 6.1.1\r\nChipset	: Qualcomm SM8650-AC Snapdragon 8 Gen 3 (4 nm)', '2024-09-03 20:12:36'),
(27, 'Two-seater Car', 3000000.00, 'MG Motor reveals two-seater electric roadster Cyberster', '2024-09-03 20:14:49'),
(28, 'GeForce RTX 4090 SUPRIM', 288900.00, 'MSI GeForce RTX 4090 SUPRIM X 24GB GDDR6X GRAPHICS CARD', '2024-09-03 20:30:08');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `created_at`) VALUES
(1, 'Taskin', 'taskinmubassir@gmail.com', '$2y$10$q4OiXMjQjzJ0QrRAoDpRaO8CCDegq2SSOpO8ritUPBeGLAraABuZa', '2024-09-01 21:21:01'),
(4, 'Mobchu', 'm@gmail.com', '$2y$10$R9YoNxRzxKwy5t72IDgDauZhB.I0o3nJeuA8ZchkAXff6YC51Fcda', '2024-09-01 22:50:17'),
(7, 'Mubassir', 'mubassir@gmail.com', '$2y$10$Anwi1CrJHs/nh5WiLSSS2O12vI8cnQ7ixUYXESGc0gZgOYAHMZCvO', '2024-09-02 23:02:15'),
(8, 'Tanjim', 'tanjim@gmail.com', '$2y$10$gyyLYdNEBbTH3au1Z0UxFu5P1z4DqJkj1yWpoI4Fi/8sg9Q18UMpm', '2024-09-02 23:03:43'),
(9, 'BAu Ltd.', 'bau@gmail.com', '$2y$10$uVgHsFw.xMmRcmVoqYtOb.UPqub38kgZzQ5sgGwWELc4w8ZAI/EGa', '2024-09-02 23:14:02'),
(10, 'tasku', 'tasku@gmail.com', '$2y$10$N95NEQ9lOZDFkyZIVTjm2e6rATJYQR.hnHxd2BHlJNO6fdy7GCc3i', '2024-09-03 19:24:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
